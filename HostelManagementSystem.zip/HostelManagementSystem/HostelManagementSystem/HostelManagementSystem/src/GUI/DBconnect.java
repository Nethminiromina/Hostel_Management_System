/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Nethmini Romina
 */
public class DBconnect {

    private static final String url = "jdbc:mysql://localhost:3306/HostelManagementSystem";
    private static final String un = "root";
    private static final String pw = "";

    Connection conn;

    public static Connection ConnectorDB() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection(url, un, pw);
            return conn;
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, e);
            return null;
        }

    }

    public static void main(String[] args) {
        Welcome wel = new Welcome();
        wel.setLocationRelativeTo(null);
        wel.setVisible(true);
    }

}
