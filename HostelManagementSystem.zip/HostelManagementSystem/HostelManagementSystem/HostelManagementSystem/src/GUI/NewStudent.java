package GUI;

import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class NewStudent extends javax.swing.JFrame {

    private PreparedStatement pstmt = null;
    private ResultSet rs = null;
    Connection conn = null;

    public NewStudent() {
        initComponents();
        conn = GUI.DBconnect.ConnectorDB();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        name = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        nicno = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        deg = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        bat = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        blo = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        room = new javax.swing.JComboBox<>();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        add = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        num = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        gname = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        rel = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        gnum = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        mail = new javax.swing.JTextField();
        dob = new com.toedter.calendar.JDateChooser();
        jButton4 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        back = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Add New Student");
        setResizable(false);

        jPanel1.setPreferredSize(new java.awt.Dimension(700, 480));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(javax.swing.UIManager.getDefaults().getColor("Button.light"));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 102), 1, true), "Add New Student", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 14))); // NOI18N
        jPanel2.setOpaque(false);
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel3.setText("Name with initials:");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, 120, 30));

        name.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        name.setToolTipText("(eg: X X X XXXXXXX)");
        jPanel2.add(name, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 40, 530, 30));

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel4.setText("NIC no:");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 50, 30));

        nicno.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        nicno.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                nicnoMouseClicked(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                nicnoMouseReleased(evt);
            }
        });
        nicno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nicnoActionPerformed(evt);
            }
        });
        jPanel2.add(nicno, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 80, 150, 30));

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel5.setText("Degree:");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 80, 60, 30));

        deg.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        deg.setMaximumRowCount(10);
        deg.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-select-", "UGC (Computing)", "UGC (Management)", "UCD (Computing)", "UCD (Management)", "Limkokwing", "Victoria" }));
        deg.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                degPopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
            }
        });
        jPanel2.add(deg, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 80, 350, 30));

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel6.setText("Batch:");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, 60, 30));

        bat.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        bat.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-select-", "16.1", "16.2", "17.1", "17.2", "18.1", "18.2" }));
        jPanel2.add(bat, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 120, 110, 30));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel7.setText("Block:");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 310, 60, 30));

        blo.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        blo.setMaximumRowCount(3);
        blo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-select-", "A", "B" }));
        blo.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                bloItemStateChanged(evt);
            }
        });
        blo.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                bloPopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
            }
        });
        blo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bloMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                bloMouseEntered(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                bloMouseReleased(evt);
            }
        });
        blo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bloActionPerformed(evt);
            }
        });
        jPanel2.add(blo, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 310, 130, 30));

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel8.setText("Room no:");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 310, 70, 30));

        room.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        room.setMaximumRowCount(121);
        room.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-select-" }));
        jPanel2.add(room, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 310, 170, 30));
        jPanel2.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 290, 660, 10));

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel9.setText("Date of Birth:");
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 120, 90, 30));

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel10.setText("Address:");
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 70, 30));

        add.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addActionPerformed(evt);
            }
        });
        jPanel2.add(add, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 160, 580, 30));

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel11.setText("Contact No:");
        jPanel2.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, -1, 30));

        num.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        num.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                numActionPerformed(evt);
            }
        });
        num.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                numKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                numKeyTyped(evt);
            }
        });
        jPanel2.add(num, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 200, 120, 30));

        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel12.setText("Guardian's name:");
        jPanel2.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 200, 190, 30));

        gname.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jPanel2.add(gname, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 200, 300, 30));

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel13.setText("Relationship:");
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 240, 90, 30));

        rel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                relActionPerformed(evt);
            }
        });
        jPanel2.add(rel, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 240, 250, 30));

        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel14.setText("Guardian's contact no:");
        jPanel2.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 240, 130, 30));

        gnum.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        gnum.setName(""); // NOI18N
        gnum.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gnumActionPerformed(evt);
            }
        });
        gnum.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                gnumKeyTyped(evt);
            }
        });
        jPanel2.add(gnum, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 240, 140, 30));

        jLabel15.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jLabel15.setText("(for office purpose only)");
        jPanel2.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 300, 310, -1));

        jLabel16.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel16.setText("E-mail:");
        jPanel2.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 120, 60, 30));

        mail.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jPanel2.add(mail, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 120, 120, 30));

        dob.setToolTipText("Select your birthday");
        dob.setDateFormatString("yyyy-MM-dd");
        dob.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dobMouseClicked(evt);
            }
        });
        dob.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                dobPropertyChange(evt);
            }
        });
        jPanel2.add(dob, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 120, 150, 30));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 680, 360));

        jButton4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton4.setText("Logout");
        jButton4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 0, 102), new java.awt.Color(0, 0, 102), new java.awt.Color(0, 0, 102), new java.awt.Color(0, 0, 102)));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 10, 120, 40));

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton2.setText("SUBMIT");
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton2MousePressed(evt);
            }
        });
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 420, 90, 40));

        back.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        back.setText("< Back");
        back.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });
        jPanel1.add(back, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 420, 90, 40));

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/b.jpeg"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 700, 480));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addActionPerformed

    }//GEN-LAST:event_addActionPerformed

    private void relActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_relActionPerformed

    }//GEN-LAST:event_relActionPerformed

    private void gnumActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gnumActionPerformed

    }//GEN-LAST:event_gnumActionPerformed

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        setVisible(false);
    }//GEN-LAST:event_backActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

    }//GEN-LAST:event_jButton2ActionPerformed

    private void degPopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_degPopupMenuWillBecomeInvisible

    }//GEN-LAST:event_degPopupMenuWillBecomeInvisible

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        Welcome wel = new Welcome();
        wel.setLocationRelativeTo(null);
        Options op = new Options();
        op.setVisible(false);
        setVisible(false);
        wel.setVisible(true);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void dobMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dobMouseClicked

    }//GEN-LAST:event_dobMouseClicked

    private void dobPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_dobPropertyChange

    }//GEN-LAST:event_dobPropertyChange

    private void jButton2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseClicked
        String n = name.getText();
        String i = nicno.getText();
        String de = deg.getSelectedItem().toString();
        String b = bat.getSelectedItem().toString();
        String e = mail.getText();
        String a = add.getText();
        String c = num.getText();
        String gn = gname.getText();
        String re = rel.getText();
        String gc = gnum.getText();
        String bl = blo.getSelectedItem().toString();
        String r = room.getSelectedItem().toString();

        String combo = "select";

        if ("".equals(name.getText())) {
            JOptionPane.showMessageDialog(null, "Fill the Name", "Error", 1);
        } else if ("".equals(nicno.getText()) || !(nicno.getText().trim().matches("^[0-9]{9}[vV]$"))) {
            JOptionPane.showMessageDialog(null, "Invalid NIC no", "Error", 1);
        } else if (deg.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(null, "Choose the Degree", "Error", 1);
        } else if (bat.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(null, "Choose the Batch", "Error", 1);
        } else if ("".equals(mail.getText()) || !(mail.getText().trim().matches("[a-zA-Z0-9]+@[a-zA-Z]+.[a-zA-Z]{3}"))) {
            JOptionPane.showMessageDialog(null, "Invalid Email", "Error", 1);
        } else if ("".equals(add.getText())) {
            JOptionPane.showMessageDialog(null, "Fill the Address", "Error", 1);
        } else if ("".equals(num.getText()) || num.getText().length() > 11) {
            JOptionPane.showMessageDialog(null, "Invalid Contact number", "Error", 1);
        } else if ("".equals(gname.getText())) {
            JOptionPane.showMessageDialog(null, "Fill the Guardian's name", "Error", 1);
        } else if ("".equals(rel.getText())) {
            JOptionPane.showMessageDialog(null, "Fill the Relationship", "Error", 1);
        } else if ("".equals(gnum.getText()) || gnum.getText().length() > 11) {
            JOptionPane.showMessageDialog(null, "Invalid Guardian's Contact number", "Error", 1);
        } else if (blo.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(null, "Choose the block", "Error", 1);
        } else if ("".equals(room.getSelectedItem().toString())) {
            JOptionPane.showMessageDialog(null, "Choose the room number", "Error", 1);
        } else if (dob.getDate() == null) {
            JOptionPane.showMessageDialog(null, "Select a date", "Error", 1);
        } else {

            DateFormat df = DateFormat.getDateInstance();
            String dt = df.format(dob.getDate());

            try {

                pstmt = conn.prepareStatement("insert into student values(?,?,?,?,?,?,?,?,?,?,?,?,?)");

                pstmt.setString(1, n);
                pstmt.setString(2, i);
                pstmt.setString(3, de);
                pstmt.setString(4, b);
                pstmt.setString(5, dt);
                pstmt.setString(6, a);
                pstmt.setString(7, e);
                pstmt.setString(8, c);
                pstmt.setString(9, gn);
                pstmt.setString(10, re);
                pstmt.setString(11, gc);
                pstmt.setString(12, bl);
                pstmt.setString(13, r);

                pstmt.executeUpdate();

                updateStatus();

                JOptionPane.showMessageDialog(null, "Sucessfully added the new student", "Done", 1);

                setVisible(false);
            } catch (SQLException ex) {
                Logger.getLogger(NewStudent.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_jButton2MouseClicked
    private void updateStatus() {
        /*update status*/
        String roomn = room.getSelectedItem().toString();
        int znum = 0;
        String zz;

        try {
            pstmt = conn.prepareStatement("SELECT rooms.`status` FROM rooms WHERE rooms.roomNo = ?");
            pstmt.setString(1, roomn);
            rs = pstmt.executeQuery();
            System.out.println("Searched");
            while (rs.next()) {
                String all = rs.getString("status");
                znum = Integer.parseInt(all);
                //increment
                znum = znum + 1;
                zz = String.valueOf(znum);
                
                System.out.println("Done");
                
                PreparedStatement ps;
                ps = conn.prepareStatement("UPDATE rooms SET status = ? WHERE roomNo = ?");
                ps.setString(1, zz);
                ps.setString(2, roomn);

                ps.executeUpdate();

                System.out.println("Updated");
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewStudent.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    private void numKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_numKeyTyped
        char c = evt.getKeyChar();
        if (!(Character.isDigit(c)) || c == KeyEvent.VK_BACK_SPACE || c == KeyEvent.VK_DELETE) {
            evt.consume();
        }
    }//GEN-LAST:event_numKeyTyped

    private void numKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_numKeyPressed

    }//GEN-LAST:event_numKeyPressed

    private void numActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_numActionPerformed

    }//GEN-LAST:event_numActionPerformed

    private void gnumKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_gnumKeyTyped
        char c = evt.getKeyChar();
        if (!(Character.isDigit(c)) || c == KeyEvent.VK_BACK_SPACE || c == KeyEvent.VK_DELETE) {
            evt.consume();
        }
    }//GEN-LAST:event_gnumKeyTyped

    private void bloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bloActionPerformed

    }//GEN-LAST:event_bloActionPerformed

    private void bloMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bloMouseClicked

    }//GEN-LAST:event_bloMouseClicked

    private void bloMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bloMouseReleased

    }//GEN-LAST:event_bloMouseReleased

    private void bloItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_bloItemStateChanged
        room.removeAllItems();
    }//GEN-LAST:event_bloItemStateChanged

    private void bloMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bloMouseEntered

    }//GEN-LAST:event_bloMouseEntered

    private void bloPopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_bloPopupMenuWillBecomeInvisible
        try {
            pstmt = conn.prepareStatement("SELECT * FROM rooms WHERE status IN ('1','0') AND block = ?");
            pstmt.setString(1, blo.getSelectedItem().toString());
            rs = pstmt.executeQuery();

            while (rs.next()) {
                String n = rs.getString("roomNo");
                room.addItem(n);
            }
        } catch (SQLException e) {
        }
    }//GEN-LAST:event_bloPopupMenuWillBecomeInvisible

    private void nicnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nicnoActionPerformed

    }//GEN-LAST:event_nicnoActionPerformed

    private void nicnoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nicnoMouseClicked

    }//GEN-LAST:event_nicnoMouseClicked

    private void nicnoMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nicnoMouseReleased
        try {
            pstmt = conn.prepareStatement("SELECT * FROM  student WHERE nic = ?");
            pstmt.setString(1, nicno.getText());
            rs = pstmt.executeQuery();
            while (rs.next()) {
                if (nicno.getText().equals(rs.getString("nic"))) {
                    JOptionPane.showMessageDialog(null, "NIC no has been used previously");
                }
            }
        } catch (SQLException e) {

        }
    }//GEN-LAST:event_nicnoMouseReleased

    private void jButton2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MousePressed

    }//GEN-LAST:event_jButton2MousePressed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NewStudent().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField add;
    private javax.swing.JButton back;
    private javax.swing.JComboBox<String> bat;
    private javax.swing.JComboBox<String> blo;
    private javax.swing.JComboBox<String> deg;
    private com.toedter.calendar.JDateChooser dob;
    private javax.swing.JTextField gname;
    private javax.swing.JTextField gnum;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTextField mail;
    private javax.swing.JTextField name;
    private javax.swing.JTextField nicno;
    private javax.swing.JTextField num;
    private javax.swing.JTextField rel;
    private javax.swing.JComboBox<String> room;
    // End of variables declaration//GEN-END:variables
}
